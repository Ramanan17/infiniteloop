A Pen created at CodePen.io. You can find this one at https://codepen.io/juliangarnier/pen/rGjMyW.

 Animating 4 transforms properties on +200 dom elements with individual timing values. 